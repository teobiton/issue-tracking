<!-- If you want to report a bug, please fill out the information below.
Otherwise, feel free to remove these lines.-->


<!-- Insert short summary -->

I tried this code:

<!-- Insert code sample -->

I expected to see this happen:

Instead this happened:

## Meta

predicates-rs version:
`rustc --version --verbose`:
