# `#[wasm_bindgen]` on Rust Exports

This section enumerates the attributes available for customizing bindings for
Rust functions and `struct`s exported to JavaScript.
