exports.foo = () => {};
exports.bar = 3;
